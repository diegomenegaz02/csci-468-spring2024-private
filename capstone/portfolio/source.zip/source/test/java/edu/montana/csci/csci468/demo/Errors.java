package edu.montana.csci.csci468.demo;

public class Errors {

    public static void main(String[] args) {
//        pretty sad state of affairs...
//        oh well
                int x = 10;
    }

}
